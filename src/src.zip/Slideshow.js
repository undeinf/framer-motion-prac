import { AnimatePresence, motion } from 'framer-motion';
import React, { useMemo, useState } from 'react';
// import "./Slideshow.css";
import { Container, ButtonNext, ButtonPrev, Items } from './Slideshow-style';

const Slideshow = ({ active, children, visible = 3 }) => {
    const [activeIndex, setActiveIndex] = useState(active);
    const imagesList = useMemo(() => children, [children]);
    const counterRef = useMemo(() => Math.round(visible / 2), [visible]);//3

    const generate = () => {
        const items = [];
        let counter = counterRef;
        console.log('counter', counter)
        console.log('visible - counterRef', visible - counterRef)
        console.log('activeIndex - 1', activeIndex - 1);//0
        console.log('activeIndex + 2', activeIndex + 2);//3
        console.log('difference', (activeIndex + 2) - (activeIndex - 1));//3
        for (let i = activeIndex - 1; i < activeIndex + 2; i++) {
            // console.log('i', i)
            let index = i;
            if (i < 0) {
                index = imagesList.length + i;
            } else if (i >= imagesList.length) {
                index = i % imagesList.length;
            }
            // console.log('index', index)
            items.push(
                <motion.div key={index}
                    className={'item level' + counter}
                    positionTransition={{
                        damping: 150,
                        stiffness: 500
                    }}
                    animate={{ scale: visible - counterRef === 1 ? 1 : 0 }}
                >
                    {imagesList[index]}
                </motion.div>
            )
            counter--;
        }
        return items;
    }

    const handleNext = () => {
        let newActive = activeIndex;
        setActiveIndex((newActive + 1) % imagesList.length)
    }

    const handlePrev = () => {
        let newActive = activeIndex;
        newActive--;
        setActiveIndex(newActive < 0 ? imagesList.length - 1 : newActive)
    }

    return (
        <>
            <Container>
                <ButtonPrev onClick={handlePrev}>
                    <span>Previus : {activeIndex}</span>
                </ButtonPrev>
                <Items >
                    {generate()}
                </Items>
                <ButtonNext onClick={handleNext}>
                    <span>Next</span>
                </ButtonNext>
            </Container>
        </>
    )
}

export default Slideshow;